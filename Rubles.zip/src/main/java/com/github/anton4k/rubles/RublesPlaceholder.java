package com.github.anton4k.rubles;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;

public class RublesPlaceholder extends PlaceholderExpansion {

    private final Rubles plugin;

    public RublesPlaceholder(Rubles plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getIdentifier() {
        return "rubles";
    }

    @Override
    public String getAuthor() {
        return "anton4k";
    }

    @Override
    public String getVersion() {
        return "1.0-SNAPSHOT";
    }

    @Override
    public String onPlaceholderRequest(Player player, String identifier) {
        if (player == null) return "";
        if (identifier.equals("balance")) {
            return String.valueOf(plugin.getDataConfig().getInt("players." + player.getUniqueId() + ".balance", 0));
        }
        return null;
    }
}